document.addEventListener("DOMContentLoaded", function () {
    const countryData = {
        "Russia": {
            admission: [
                "Research and choose a university.",
                "Check eligibility criteria.",
                "Submit application form.",
                "Receive admission letter.",
                "Apply for student visa.",
                "Pay tuition fees.",
                "Travel and join the program."
            ],
            eligibility: [
                "Minimum 75% in 12th grade (PCB).",
                "Age limit: 17-25 years.",
                "NEET qualification (for Indian students).",
                "English proficiency (if required).",
                "Medical fitness certificate."
            ],
            contact: "Contact: admissions@russia-mbbs.com"
        }
    };

    document.querySelectorAll(".country-btn").forEach(button => {
        button.addEventListener("click", function () {
            const country = this.getAttribute("data-country");
            document.getElementById("country-name").textContent = country;
            document.getElementById("admission-process").innerHTML =
                countryData[country]?.admission.map(step => `<li>${step}</li>`).join('') || "Details not available";
            document.getElementById("eligibility-criteria").innerHTML =
                countryData[country]?.eligibility.map(criteria => `<li>${criteria}</li>`).join('') || "Details not available";
            document.getElementById("contact-info").textContent =
                countryData[country]?.contact || "Contact details not available";
            document.getElementById("country-details").classList.remove("d-none");
        });
    });

    document.getElementById("applyForm").addEventListener("submit", function (event) {
        event.preventDefault();
        const name = document.getElementById("name").value;
        const email = document.getElementById("email").value;
        const phone = document.getElementById("phone").value;
        const country = document.getElementById("country").value;

        if (name && email && phone && country) {
            document.getElementById("success-message").classList.remove("d-none");
        } else {
            alert("Please fill all fields correctly!");
        }
    });
});
